dojo.provide("myapp.behavior.ShowAlertBehavior");
dojo.require("mojo.command.Behavior");

dojo.declare("myapp.behavior.ShowAlertBehavior", mojo.command.Behavior,
{
    execute: function(requestObj) {
		alert("hello world");
    }
});