dojo.provide("myapp.SiteMap");

myapp.SiteMap = [
	/*{
		pattern: "#cssSelector",
		controllers: [
			{controller: "myapp.controller.SampleController"}
		]
	}*/
];