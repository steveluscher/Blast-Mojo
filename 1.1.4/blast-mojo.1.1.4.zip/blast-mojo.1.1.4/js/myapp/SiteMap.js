dojo.provide("myapp.SiteMap");

myapp.SiteMap = [
	{
		pattern: "#testnode",
		controllers: [
			{controller: "myapp.controller.SampleController"}
		]
	}
];
