dojo.provide("myapp.controller.SampleController");
dojo.require("mojo.controller.Controller");

dojo.declare("myapp.controller.SampleController", mojo.controller.Controller,
{
    addObservers: function() {
        this.addObserver(".testlink", "onclick", "ShowAlert");
    },
    addCommands: function() {
        this.addCommand("ShowAlert", "myapp.behavior.ShowAlertBehavior");
    },
    addIntercepts: function() {
    }
});